'use client';

import { useState } from 'react';

type Sys = {
  readonly key: string;
  readonly structures: number;
  readonly triangles: number;
  readonly raw: number;
  readonly served: number;
  readonly note?: string;
};
type Metric = 'structures' | 'triangles' | 'served';

const LABEL: Record<Metric, string> = { structures: 'structures', triangles: 'triangles', served: 'MB served' };
const fmt = (m: Metric, v: number) =>
  m === 'triangles' ? `${(v / 1e6).toFixed(2)} M` : m === 'served' ? `${v.toFixed(2)} MB` : v.toLocaleString();

/* The model by system: structures, triangles, or megabytes served. */
export function SystemsChart({ systems }: { systems: readonly Sys[] }) {
  const [metric, setMetric] = useState<Metric>('structures');
  const max = Math.max(...systems.map((s) => s[metric]));
  const total = systems.reduce((a, s) => a + s[metric], 0);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1" role="tablist" aria-label="Metric">
          {(['structures', 'triangles', 'served'] as Metric[]).map((m) => (
            <button
              key={m}
              type="button"
              role="tab"
              aria-selected={metric === m}
              onClick={() => setMetric(m)}
              className={`bp-label cursor-pointer rounded-sm px-2 py-1 transition-colors duration-300 ${
                metric === m ? 'bg-ink text-ivory' : 'hover:bg-sage-soft hover:text-ink'
              }`}
            >
              {LABEL[m]}
            </button>
          ))}
        </div>
      </div>

      <ol className="mt-5 space-y-2">
        {systems.map((s) => {
          return (
            <li key={s.key} className="grid grid-cols-[7.5rem_1fr_5.5rem] items-center gap-3 md:grid-cols-[9rem_1fr_7rem]">
              <span className="font-serif text-[1rem] text-ink">{s.key}</span>
              <span className="relative block">
                <span className="bp-bar block" style={{ width: `${(s[metric] / max) * 100}%` }} />
              </span>
              <span className="bp-mono text-right text-ink tabular-nums">{fmt(metric, s[metric])}</span>
            </li>
          );
        })}
      </ol>

      <div className="bp-rule mt-5" />
      <div className="mt-3 flex flex-wrap items-baseline justify-between gap-2">
        <span className="bp-label">{systems.length} systems</span>
        <span className="font-serif text-[1.15rem] text-ink tabular-nums">
          {fmt(metric, total)} <span className="bp-mono">{LABEL[metric]}</span>
        </span>
      </div>
    </div>
  );
}
