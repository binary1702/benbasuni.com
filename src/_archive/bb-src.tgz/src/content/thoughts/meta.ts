import type { Thought } from './index';

// DRAFT — opens with the work, idea second, name last. Direct, first person,
// lesson stated plainly. Client details are generic on purpose.
export const meta: Thought = {
  slug: 'meta',
  kind: 'writing',
  title: 'Meta',
  dek: 'The most valuable question I ask\nis the one before the first one.',
  date: '2026-08-30',
  body: [
    { type: 'h', text: 'The Call' },
    {
      type: 'p',
      text: 'The owner of a $25 million construction company called me and asked for a website. He had the budget. He had the photos. He had forty trucks with his name on them and he knew exactly what he wanted it to look like.',
    },
    { type: 'p', text: 'I asked him why.' },
    {
      type: 'p',
      text: 'Not to be difficult. I asked because after ten years of building software for BlackRock, Kaiser Permanente, and banks across the country, I have learned something most people never learn: the thing people ask for is almost never the thing they need. He did not need a website. He was losing six-figure jobs to competitors who called back faster. That is a phone problem and a scheduling problem. We fixed it in a week, for a fraction of what the website would have cost, and he closed more work that quarter than in the previous two combined.',
    },
    {
      type: 'p',
      text: 'That is the lesson, and I want you to remember it: before you solve the problem, make sure it is the problem.',
    },

    { type: 'h', text: 'The First Mistake I Made' },
    {
      type: 'p',
      text: 'When I started my company, I thought my value was speed. I was the fastest engineer in every room I walked into, and I knew it. I charged by the hour. I jumped straight into building. Believe it or not, the faster I worked, the less my clients got.',
    },
    {
      type: 'p',
      text: 'The projects that made the most money and did the most good were never the ones where I wrote the most code. They were the ones where I slowed down and spent the most time asking questions. Understanding the business. Understanding the owner. Understanding what we were actually trying to change.',
    },
    { type: 'quote', text: 'I had been charging people for my hands when what they needed was my judgment.' },
    {
      type: 'p',
      text: 'The day I understood that, I tripled my rates, did half the building, and the business took off. That is not a coincidence. That is the whole game, and most people in my industry never figure it out.',
    },

    { type: 'h', text: 'The Word' },
    {
      type: 'p',
      text: 'There is a name for the move I made on that call. Stepping out of the request to look at the shape of it. Asking the question about the question. The Greeks called it *meta*: beyond, or after. Thinking about thinking.',
    },
    {
      type: 'p',
      text: 'I studied philosophy before I ever wrote software. People ask what you do with that. The answer is everything, and I am living proof. Philosophy did not teach me what to think. It taught me how, and the first thing it taught me was to notice the frame before arguing inside it. That one skill has been worth more to my clients than any line of code I have ever written.',
    },
    {
      type: 'p',
      text: 'Most disagreements are not about the answer. They are about the question. Two smart people can argue for an hour and never realize they are solving different problems. The meta move is simple: stop, say the problem out loud, and see if everyone nods. If they do not, you have found the real work.',
    },
    {
      type: 'list',
      items: [
        'Before you answer, ask what the question is for.',
        'Before you fix a part, ask what it is a part of.',
        'When people disagree, check whether they are solving the same problem.',
      ],
    },
    { type: 'p', text: 'Do that, and most of the time the technology becomes obvious. Skip it, and no technology will save you.' },
  ],
};
