import type { Metadata } from 'next';
import Link from 'next/link';
import { Reveal } from '@/components';
import { SystemsChart } from '@/components/blueprint/SystemsChart';
import { skeletor as S } from '@/content/work/skeletor';
import { SITE_URL, SITE_NAME, AUTHOR } from '@/lib/site';

const description = S.oneLine;

export const metadata: Metadata = {
  title: { absolute: '/work/skeletor' },
  description,
  alternates: { canonical: '/work/skeletor' },
  openGraph: {
    type: 'article',
    title: `${S.name} — a blueprint`,
    description,
    url: '/work/skeletor',
    siteName: SITE_NAME,
    images: [{ url: S.hero.src, width: 2068, height: 1378, alt: S.hero.alt }],
  },
  twitter: { card: 'summary_large_image', title: S.name, description },
};

/* Section header in the drawing idiom: "SECTION 02 — PIPELINE" over a ruled line. */
function Section({ n, title, children, note }: { n: string; title: string; note?: string; children: React.ReactNode }) {
  return (
    <Reveal as="section" className="mt-14 md:mt-20">
      <div className="flex items-baseline justify-between gap-4">
        <h2 className="flex items-baseline gap-3">
          <span className="bp-mono text-ink">{n}</span>
          <span className="bp-label text-ink normal-case">{title}</span>
        </h2>
        {note && <span className="bp-mono hidden md:block">{note}</span>}
      </div>
      <div className="bp-rule mt-2" />
      <div className="mt-6">{children}</div>
    </Reveal>
  );
}

export default function SkeletorPage() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareSourceCode',
    name: S.name,
    description,
    url: `${SITE_URL}/work/skeletor`,
    author: { '@type': 'Person', name: AUTHOR.name, url: AUTHOR.url },
    programmingLanguage: ['Python', 'TypeScript'],
    runtimePlatform: 'Web',
    isBasedOn: { '@type': 'Dataset', name: S.source.name, url: S.source.url, license: 'https://creativecommons.org/licenses/by-sa/4.0/' },
    dateModified: '2026-10-29',
  };


  return (
    <main data-theme="blueprint" className="relative z-20 mx-auto max-w-[72rem] px-5 py-10 sm:px-8 md:px-12 md:py-14">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      {/* ---- sheet header: way back + title block ---- */}
      <Reveal as="header">
        <Link href="/" className="bp-label transition-colors duration-500 hover:text-ink">
          ← Ben Basuni
        </Link>
        {/* Title block: centered on the name + one-liner only (the back link is outside the row). */}
        <div className="mt-6 flex items-center justify-between gap-6">
          <div>
            <h1 className="font-serif font-light leading-[1] tracking-[-0.02em] text-ink" style={{ fontSize: 'clamp(2rem, 4.2vw, 3.5rem)' }}>
              <a href={S.live.url} target="_blank" rel="noopener noreferrer" className="transition-colors duration-500 hover:text-sage">
                {S.live.url.replace('https://', '')}
              </a>
            </h1>
            <p className="mt-4 max-w-[44rem] font-serif text-[1.05rem] font-light italic leading-[1.5] text-charcoal md:text-[1.2rem]">
              {S.oneLine}
            </p>
          </div>

          {/* title block */}
          <table className="bp-mono hidden shrink-0 self-center border border-rule md:table">
            <tbody>
              {[
                ['SHEET', S.sheet.number],
                ['REV', S.sheet.rev],
                ['DATE', S.sheet.date],
                ['DRAWN', S.sheet.author],
                ['SOURCE', `${S.source.name} · ${S.source.license}`],
              ].map(([k, v]) => (
                <tr key={k} className="border-b border-rule last:border-0">
                  <td className="border-r border-rule px-3 py-1.5">{k}</td>
                  <td className="px-3 py-1.5 text-ink">{v}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Reveal>

      {/* ---- 01 the thing itself ---- */}
      <Reveal as="section" className="mt-10 md:mt-14">
        <figure>
          <a href={S.live.url} target="_blank" rel="noopener noreferrer" className="group block overflow-hidden rounded-xl border border-rule">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={S.hero.src} alt={S.hero.alt} width={2068} height={1378} className="h-auto w-full transition-transform duration-700 group-hover:scale-[1.01]" />
          </a>
          <figcaption className="mt-3 flex justify-end">
            <a href={S.live.url} target="_blank" rel="noopener noreferrer" className="bp-label text-ink underline decoration-ink/30 underline-offset-4 hover:decoration-sage">
              open the viewer →
            </a>
          </figcaption>
        </figure>

      </Reveal>

      {/* ---- 02 history & roadmap ---- */}
      <Section n="01" title="History & Roadmap">
        <ol className="relative border-l border-rule pl-6">
          {S.timeline.map((t) => (
            <li key={t.date + t.what} className="relative pb-5 last:pb-0">
              <span
                aria-hidden="true"
                className={`absolute -left-[1.6rem] top-1.5 h-2.5 w-2.5 rounded-full border ${
                  t.status === 'done' ? 'border-ink bg-ink' : 'border-rule bg-ivory'
                }`}
              />
              <div className="grid gap-x-4 gap-y-1 md:grid-cols-[6.5rem_1fr]">
                <span className="bp-mono text-ink">{t.date || (t.status === 'next' ? 'next' : '')}</span>
                <span className={`font-serif text-[1.1rem] font-light leading-[1.5] ${t.status === 'next' ? 'text-charcoal' : 'text-ink'}`}>{t.what}</span>
              </div>
            </li>
          ))}
        </ol>
      </Section>

      {/* ---- 02 what the model keeps ---- */}
      <Section n="02" title="Model Information">
        <SystemsChart systems={S.systems} />
      </Section>

      {/* ---- 03 engineering principles ---- */}
      <Section n="03" title="Engineering Principles" note={S.principlesIntro}>
        <p className="bp-mono -mt-2 mb-8 md:hidden">{S.principlesIntro}</p>
        <ol className="grid gap-x-12 gap-y-12 md:grid-cols-2 md:gap-y-14">
          {S.principles.map((q, i) => (
            <li key={q.discipline} className="flex flex-col">
              {/* A. number + B. discipline */}
              <div className="flex items-baseline gap-4">
                <span className="bp-mono text-ink">{String(i + 1).padStart(2, '0')}</span>
                <span className="bp-label text-ink">{q.discipline}</span>
              </div>
              {/* C. principle */}
              <h3 className="mt-4 font-serif text-[1.5rem] font-light leading-[1.15] tracking-[-0.01em] text-ink md:text-[1.75rem]">
                {q.headline}
              </h3>
              {/* D. explanation */}
              <div className="mt-4 space-y-3">
                {q.body.map((para) => (
                  <p key={para} className="font-serif text-[1rem] font-light leading-[1.55] text-charcoal">
                    {para}
                  </p>
                ))}
              </div>
              {/* D. result, stamped like a dimension */}
              <div className="mt-5">
                <div className="bp-rule" />
                <p className="bp-mono mt-2 text-ink">{q.result}</p>
              </div>
              {/* E. competencies: classification labels, pushed to the quadrant's foot */}
              <p className="bp-mono mt-auto pt-5 uppercase tracking-[0.12em]">{q.competencies.join('  /  ')}</p>
            </li>
          ))}
        </ol>
      </Section>

    </main>
  );
}
