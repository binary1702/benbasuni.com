import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  allowedDevOrigins: ["lh"],
};

export default nextConfig;